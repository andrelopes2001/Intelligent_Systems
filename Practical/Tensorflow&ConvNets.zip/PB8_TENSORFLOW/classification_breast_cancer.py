# %% Import required packages
import tensorflow as tf
from sklearn.datasets import load_breast_cancer
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, recall_score, precision_score
from sklearn.preprocessing import MinMaxScaler
from matplotlib import pyplot as plt

# %% Load dataset
data_cancer = load_breast_cancer() 
X = data_cancer.data
y = data_cancer.target
scaler = MinMaxScaler()
X = scaler.fit_transform(X)
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2)
  

# %% Initialize neural network model
model = tf.keras.Sequential([
    tf.keras.layers.Dense(32, activation='relu'),
    tf.keras.layers.Dense(32, activation='relu'),
    tf.keras.layers.Dense(1, activation='sigmoid')
])

model.compile(loss='binary_crossentropy',
              optimizer=tf.keras.optimizers.Adam(0.0001))


# %% Train model
history = model.fit(
          X_train,
          y_train,
          validation_split=0.2,
          verbose=1,
          epochs=500)

plt.plot(history.history['loss'])
plt.plot(history.history['val_loss'])

# %% Evaluate performance
y_pred = tf.greater(model.predict(X_test), 0.5)
print('Accuracy: {}\n'.format(accuracy_score(y_test, y_pred)))

