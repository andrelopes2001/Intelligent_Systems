This tutorial shows how to use the pyfume python package to create fuzzy models from data. It provides three examples for the most common types of problems using well known benchmark datasets:

==> Binary Classification (binary_classification.py): using the Wisconsin Breast Cancer dataset
==> MultiClass Classification (multi_classification_ova.py): using the Iris dataset and a one-vs-all approach
==> Multiple Input Single Output (MISO) Regression: using the Auto MPG dataset

In order to install the pyfume package follow these steps:

[1] - Go to the search function of the windows start menu, type "anaconda prompt" and open Anaconda Prompt
[2] - Type "pip install pyfume" and press enter
[3] - Wait until the instalation process ends and close the prompt

It is also recommended to read the original paper proposing the pyfume package, as well as the documentation which are also included in this folder.
