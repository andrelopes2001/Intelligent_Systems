# %% Import packages
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
import tensorflow as tf
from sklearn.preprocessing import MinMaxScaler
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense
from tensorflow.keras.layers import LSTM
from aux_functions import create_dataset

# %% Load stock price data
stock_data = pd.read_csv('DATA/stock_data.csv')
stock_data.head()
price_data = stock_data.reset_index()['Close']

# %% Plot price data
plt.plot(price_data)

# %% Preprocess the data
scaler = MinMaxScaler()
price_data = scaler.fit_transform(np.array(price_data).reshape(-1,1))
plt.plot(price_data)

# %% Create train-test split
train_size = int(len(price_data)*0.65)
test_size = len(price_data) - train_size
train_data,test_data = price_data[0:train_size,:],price_data[train_size:len(price_data),:1]
time_step = 100
X_train,Y_train =  create_dataset(train_data,time_step)
X_test,Y_test =  create_dataset(test_data,time_step)

# %% Initialize LSTM model (1 input layer and 2 hidden layers with 50 neurons, 1 output layer)
model = Sequential()
model.add(LSTM(50,return_sequences = True,input_shape = (X_train.shape[1],1)))
model.add(LSTM(50,return_sequences = True))
model.add(LSTM(50))
model.add(Dense(1))
model.compile(loss = 'mean_squared_error',optimizer = 'adam')
model.summary()

# %% Train model
model.fit(X_train,Y_train,validation_data = (X_test,Y_test),epochs = 100,batch_size = 64,verbose = 1)
model.save('MODELS/lstm_price_forecast.keras')

# %% Get model predictions 
model = tf.keras.models.load_model('MODELS/lstm_price_forecast.keras')
train_predict = model.predict(X_train)
test_predict = model.predict(X_test)
train_predict = scaler.inverse_transform(train_predict)
test_predict = scaler.inverse_transform(test_predict)

# %% Plot model predictions
look_back = 100
trainPredictPlot = np.empty_like(price_data)
trainPredictPlot[:,:] = np.nan
trainPredictPlot[look_back : len(train_predict)+look_back,:] = train_predict
testPredictPlot = np.empty_like(price_data)
testPredictPlot[:,:] = np.nan
testPredictPlot[len(train_predict)+(look_back)*2 + 1 : len(price_data) - 1,:] = test_predict
plt.plot(scaler.inverse_transform(price_data))
plt.plot(trainPredictPlot)
plt.plot(testPredictPlot)
plt.show()
